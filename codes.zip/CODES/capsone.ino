#include <Wire.h>
#include <Adafruit_AS7343.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

Adafruit_AS7343 as7343;

#define WHITE_LED 27
#define IR_LED 25

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

const uint8_t NUM_CHANNELS = 12;

const as7343_channel_t channels[NUM_CHANNELS] = {
  AS7343_CHANNEL_F1,AS7343_CHANNEL_F2,AS7343_CHANNEL_FZ,
  AS7343_CHANNEL_F3,AS7343_CHANNEL_F4,AS7343_CHANNEL_F5,
  AS7343_CHANNEL_FY,AS7343_CHANNEL_FXL,AS7343_CHANNEL_F6,
  AS7343_CHANNEL_F7,AS7343_CHANNEL_F8,AS7343_CHANNEL_NIR
};

const char *labels[NUM_CHANNELS] = {
  "F1","F2","FZ","F3","F4","F5","FY","FXL","F6","F7","F8","NIR"
};

void setup() {

  Serial.begin(115200);
  delay(1000);

  pinMode(WHITE_LED, OUTPUT);
  pinMode(IR_LED, OUTPUT);

  digitalWrite(WHITE_LED, LOW);
  digitalWrite(IR_LED, LOW);

  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.clearDisplay();

  Serial.println("AS7343 Plastic Detection System");

  if (!as7343.begin()) {
    Serial.println("Sensor not detected!");
    while (1);
  }

  as7343.setGain(AS7343_GAIN_64X);
  as7343.setATIME(29);
  as7343.setASTEP(599);

  Serial.println("Sensor ready");
}

void loop() {

  uint16_t readings[18];

 
  digitalWrite(IR_LED, LOW);
  digitalWrite(WHITE_LED, HIGH);
  delay(200);

  as7343.readAllChannels(readings);

  Serial.println("\n===== WHITE LED SPECTRUM =====");

  for (int i = 0; i < NUM_CHANNELS; i++) {
    Serial.print(labels[i]);
    Serial.print(" : ");
    Serial.println(readings[channels[i]]);
  }

  digitalWrite(WHITE_LED, LOW);
  delay(300);

  
  digitalWrite(IR_LED, HIGH);
  delay(200);

  as7343.readAllChannels(readings);

  Serial.println("\n===== IR LED RESPONSE =====");

  for (int i = 0; i < NUM_CHANNELS; i++) {
    Serial.print(labels[i]);
    Serial.print(" : ");
    Serial.println(readings[channels[i]]);
  }

  int nirValue = readings[AS7343_CHANNEL_NIR];

digitalWrite(IR_LED, LOW);

Serial.print("NIR Value: ");

Serial.println(nirValue);

display.clearDisplay();

display.setTextSize(2);

display.setTextColor(WHITE);

display.setCursor(0,20);



if(nirValue >= 1800 && nirValue < 2210){

    display.println("HDPE");

    Serial.println("Plastic detected: HDPE");

}

else if(nirValue >= 2210 && nirValue < 3000){

    display.println("LDPE");

    Serial.println("Plastic detected: LDPE");

}

else if(nirValue >= 3000 && nirValue <= 4000){

    display.println("PP");

    Serial.println("Plastic detected: PP");

}

else{

    display.println("Unknown");

    Serial.println("Plastic detected: UNKNOWN");

}

display.display();
  delay(2000);
}